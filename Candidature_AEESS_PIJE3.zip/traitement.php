<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = $_POST;
    $to = "Yapylema@gmail.com";
    $subject = "Nouvelle candidature - PIJE 3 (AEESS)";
    
    $message = "
    <h2>Nouvelle candidature reçue – PIJE 3</h2>
    <p><strong>Nom :</strong> {$data['nom']} {$data['prenom']}</p>
    <p><strong>Sexe :</strong> {$data['sexe']}</p>
    <p><strong>Date de naissance :</strong> {$data['date_naissance']}</p>
    <p><strong>Lieu de naissance :</strong> {$data['lieu_naissance']}</p>
    <p><strong>École :</strong> {$data['ecole']}</p>
    <p><strong>Quartier :</strong> {$data['quartier']}</p>
    <p><strong>Contact :</strong> {$data['contact']}</p>
    <p><strong>Tuteur :</strong> {$data['tuteur']} ({$data['contact_tuteur']})</p>
    <p><strong>Pigeonnier :</strong> {$data['pigeonnier']}</p>
    <p><strong>Grillage :</strong> {$data['grillage']}</p>
    <p><strong>Sécurisé :</strong> {$data['securise']}</p>
    <p><strong>Prêt à suivre des formations :</strong> {$data['formation']}</p>
    <br>
    <a href='https://tonsite.com/validation.php?nom={$data['nom']}&prenom={$data['prenom']}'>➡️ Valider cette candidature</a>
    ";

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@tonsite.com";

    mail($to, $subject, $message, $headers);
    header("Location: confirmation.html");
    exit;
}
?>