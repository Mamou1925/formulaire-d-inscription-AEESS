<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $decision = $_POST['decision'];
    $to = "aeessomadougou@yahoo.com";
    $subject = "Décision finale - PIJE 3 (AEESS)";
    $message = "
    <h2>Décision sur la candidature PIJE 3</h2>
    <p>Nom du candidat : {$_POST['nom']} {$_POST['prenom']}</p>
    <p>Décision : <strong>$decision</strong></p>
    ";
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: noreply@tonsite.com";

    mail($to, $subject, $message, $headers);
    echo "<h2>Décision envoyée à AEESS. Merci !</h2>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Validation du candidat - PIJE 3</title>
</head>
<body>
<h2>Validation de la candidature</h2>
<form method="POST">
  <input type="hidden" name="nom" value="<?php echo $_GET['nom'] ?? ''; ?>">
  <input type="hidden" name="prenom" value="<?php echo $_GET['prenom'] ?? ''; ?>">
  <label>Décision :</label><br>
  <select name="decision">
    <option value="Approuvé">Approuvé</option>
    <option value="Non approuvé">Non approuvé</option>
  </select><br><br>
  <button type="submit">Envoyer à AEESS</button>
</form>
</body>
</html>